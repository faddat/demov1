use super::{Address, CoinId, CoinSpec, COINS_NAMESPACE};
#[cfg(feature = "ledger")]
use super::{LedgerError, TokenDefinition};
use commonware_codec::{Encode, EncodeSize, Read, ReadExt, Write};
use commonware_cryptography::{Hasher, Sha256};

/// Deterministic token factory used by the coin ledger.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct TokenFactory {
    next_nonce: u64,
}

impl TokenFactory {
    /// Reconstruct a factory from a persisted nonce, so token-id derivation stays deterministic
    /// across restarts when the factory state lives in a [`crate::Ledger`]'s database.
    pub fn with_nonce(next_nonce: u64) -> Self {
        Self { next_nonce }
    }

    pub fn next_nonce(&self) -> u64 {
        self.next_nonce
    }

    pub fn derive_coin_id(issuer: &Address, nonce: u64, spec: &CoinSpec) -> CoinId {
        let mut hasher = Sha256::default();
        hasher.update(COINS_NAMESPACE);
        hasher.update(&issuer.encode());
        hasher.update(&nonce.encode());
        hasher.update(&spec.encode());
        CoinId(hasher.finalize().1)
    }

    #[cfg(feature = "ledger")]
    pub fn create(
        &mut self,
        issuer: Address,
        spec: CoinSpec,
    ) -> Result<TokenDefinition, LedgerError> {
        validate_spec(&spec)?;
        let nonce = self.next_nonce;
        self.next_nonce = self
            .next_nonce
            .checked_add(1)
            .ok_or(LedgerError::NonceOverflow)?;
        let id = Self::derive_coin_id(&issuer, nonce, &spec);
        Ok(TokenDefinition::from_spec(id, issuer, spec))
    }
}

#[cfg(feature = "ledger")]
fn validate_spec(spec: &CoinSpec) -> Result<(), LedgerError> {
    if let Some(max_supply) = spec.max_supply {
        if spec.initial_supply > max_supply {
            return Err(LedgerError::MaxSupplyExceeded {
                max: max_supply,
                attempted: spec.initial_supply,
            });
        }
    }
    Ok(())
}

impl Write for TokenFactory {
    fn write(&self, buf: &mut impl bytes::BufMut) {
        self.next_nonce.write(buf);
    }
}

impl Read for TokenFactory {
    type Cfg = ();

    fn read_cfg(buf: &mut impl bytes::Buf, _: &Self::Cfg) -> Result<Self, commonware_codec::Error> {
        Ok(Self {
            next_nonce: u64::read(buf)?,
        })
    }
}

impl EncodeSize for TokenFactory {
    fn encode_size(&self) -> usize {
        self.next_nonce.encode_size()
    }
}
